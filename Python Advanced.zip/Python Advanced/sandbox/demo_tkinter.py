import tkinter as tk
from tkinter import messagebox

top = tk.Tk()

def hello():
    messagebox.showerror("Say Hello", "Hello World")

btn1 = tk.Button(top, text = "Say Hello", command = hello)
btn1.pack()

top.mainloop()
