import xml.etree.ElementTree as ET

tree = ET.parse(r'..\data\macbeth.xml')
root = tree.getroot()

for act in root.findall('.//ACT'):
    print(act.find('TITLE').text, '------------------------------------')
    for scene in act.findall('.//SCENE/TITLE'):
        print(scene.text)
