import random

ranks = '2,3,4,5,6,7,8,9,10,B,V,H,A'.split(',')
suits = '\u2663,\u2666,\u2665,\u2660'.split(',')

deck = [r+s for s in suits for r in ranks]

random.shuffle(deck)

hand = [deck.pop() for _ in range(10)]

hand.sort(key = lambda card: card[::-1])

print(hand)