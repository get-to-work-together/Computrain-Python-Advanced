import numpy as np
import matplotlib.pyplot as plt

#getallen = [random.randint(1, 100) for _ in range(16)]
# print(getallen)
# print(type(getallen))
# print(getallen + getallen)

# print()
# a = np.array(getallen)


a = np.random.randint(1, 100, 16)
print(a)
print(a + a)
print(2 * a)

a = np.arange(0, 10, 0.1)
print(a)

a = np.linspace(0, 10, 101)
print(a)

x = np.linspace(0, 10, 101)
y = np.sin(x)/(x+1)

print(x)
print(y)

plt.plot(x, y)
plt.plot(x, y * 2, marker = 'D', lw = 0)
plt.axhline(0, color='darkgray', lw=1)
plt.savefig('plot.png')
plt.show()

data = np.random.normal(10, 4, 1000)
plt.hist(data, bins = 25)
plt.show()

data1 = np.random.normal(10, 4, 100)
data2 = np.random.normal(10, 4, 100)
plt.scatter(data1, data2)
plt.show()
