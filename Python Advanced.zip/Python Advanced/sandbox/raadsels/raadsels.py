import random

raadsels = [
    {'q':'Wat is rood en vliegt door de tweede kamer?', 'a':'Een ongestelde vraag'},
    {'q': 'Wat is de volgende cijfer in de reeks 2-5-11-23?', 'a': '47'},
    {'q': 'Wanner je mijn naam luidop zegt of roept, ben ik verdwenen.', 'a': 'Stilte'},
    {'q': 'Hoe lang is een chinees.', 'a': 'Inderdaad.'},
]

def get_raadsel(i = None):
    try:
        if i is None:
            i = random.randint(0, len(raadsels) - 1)
        return raadsels[i]

    except:
        raise Exception('Invalid index')


# ----------------------------------------------------------------------

if __name__ == '__main__':

    print(get_raadsel())
