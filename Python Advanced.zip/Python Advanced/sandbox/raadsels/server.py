from flask import Flask
import raadsels

app = Flask(__name__)

@app.route('/')
def index():
    return 'Dit is de Raadsel API powered by Flask and written by the Advanced Python Training'

@app.route('/raadsel')
def get_random_raadsel():
    return raadsels.get_raadsel()

@app.route('/raadsel/<id>')
def get_raadsel(id):
    try:
        return raadsels.get_raadsel(int(id))
    except:
        return 'Invalid index', 404

app.run()
