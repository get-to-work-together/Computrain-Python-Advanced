from tkinter import *
import api

class Window(Frame):

    def __init__(self, master):
        Frame.__init__(self, master)
        self.grid() # Layout Manager
        self.build_widgets()

        self.raadsel = {'q':'Het is rood en het vliegt door de kamer', 'a':'Een ongestelde vraag'}

    def build_widgets(self):

        self.place(relx = 0.5, rely = 0.5, anchor = CENTER)

        header = Label(self,
                       text = 'Raadsels',
                       font = ('Helvetica', 40, 'bold'),
                       fg = 'Dark Blue')
        header.grid(row = 0, column = 0, pady = (30, 5))

        button1 = Button(self,
                         text = 'Ken je deze al?',
                         command = self.button1_pressed)
        button1.grid(row = 1, column = 0, pady = (30, 5))

        self.text1 = Text(self, height = 3, width = 60)
        self.text1.grid(row =  2, column = 0)

        button2 = Button(self,
                         text = 'Antwoord',
                         command = self.button2_pressed)
        button2.grid(row = 3, column = 0, pady = (30, 5))

        self.text2 = Text(self, height = 3, width = 60)
        self.text2.grid(row =  4, column = 0)

    def button1_pressed(self):
        self.raadsel = api.get_raadsel()
        self.text1.delete('1.0', 'end')
        self.text2.delete('1.0', 'end')
        self.text1.insert(END, self.raadsel['q'])

    def button2_pressed(self):
        self.text2.delete('1.0', 'end')
        self.text2.insert(END, self.raadsel['a'])

# -------------------------------------------------------------------------

root = Tk()
root.title('Raadsels')
root.geometry('500x400')

window = Window(root)

root.mainloop()