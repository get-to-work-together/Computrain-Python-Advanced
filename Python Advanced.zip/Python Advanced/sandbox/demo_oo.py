
def count_calling(func):
    count = 0

    def wrapper(*args, **kwargs):
        nonlocal count
        count += 1
        print(f'This function has now been called {count} time{"" if count==1 else "s"}.')
        return func(*args, **kwargs)

    return wrapper



class Person:

    # class-wide attribute
    FACTOR = 3

    __slots__ = ('_name', '_residence', '_age')

    def __init__(self, name, residence, age = 0):
        self._name = name
        self._residence = residence
        self._age = age

    def __repr__(self):
        return f"Person('{self._name}', '{self._residence}, {self._age})"

    def __str__(self):
        return f"Person: {self._name} - {self._residence} - {self._age}"

    def __eq__(self, other):
        return self._age == other._age
    def __ne__(self, other):
        return self._age != other._age
    def __lt__(self, other):
        return self._age < other._age
    def __le__(self, other):
        return self._age <= other._age
    def __gt__(self, other):
        return self._age > other._age
    def __ge__(self, other):
        return self._age >= other._age

    def __add__(self, other):
        return self._age + other._age

    def tell(self):
        return f'I am {self._name} and I live in {self._residence}'

    @count_calling
    def move(self, new_residence):
        self._residence = new_residence

    # Properties

    @property
    def name(self):
        return self._name.upper()

    @name.setter
    def name(self, value):
        if value:
            self._name = value
        else:
            raise Exception('Invalid name')

    @staticmethod
    def calc1(x, y):
        return (x + y) * Person.FACTOR

    @classmethod
    def calc2(cls, x, y):
        return (x + y) * cls.FACTOR

#============================================================

if __name__ == '__main__':

    p1 = Person('Peter', 'Lhee', 60)

    p2 = Person('Bas', 'Utrecht', 50)

    print(p1)
    print(p2)

    print(p1.tell())   # hetzelfde als Person.tell(p1)
    print(Person.tell(p1))
    print(p2.tell())

    p1._residence = 'Amsterdam'
    print(p1.tell())

    print(dir(p1))


