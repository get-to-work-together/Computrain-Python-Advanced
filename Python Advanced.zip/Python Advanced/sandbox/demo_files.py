
filename = 'file.csv'

try:
    with open(filename) as f:

        with open('out.tsv', 'w') as f_out:

            header = f.readline().strip().split(';')

            for line in f:

                columns = line.strip().split(';')

                d = dict(zip(header, columns))

                if d['afdeling'] == 'A':

                    print(d)

                    line_out = f'{d["naam"]}\t{d["aantal"]}\n'
                    f_out.write(line_out)


except FileNotFoundError:
    print(f'Kan deze file niet openen: {filename}')

