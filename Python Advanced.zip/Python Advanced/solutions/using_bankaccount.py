from bankaccount import BankAccount

acc1 = BankAccount('Peter', 'NL34ABDC0986754356')

print(acc1.info())

