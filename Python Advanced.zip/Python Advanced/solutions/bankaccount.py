
class Notes:

    def __init__(self):
        self._notes = []

    def add(self, note):
        self._notes.append(note)

    def retrieve(self):
        self._notes.pop()

    @property
    def number_of_notes(self):
        return f'{len(self._notes)} notes'

class BankAccount:

    currency = '€'

    def __init__(self, holder, nr):
        self._holder = holder
        self._nr = nr
        self.__balance = 0

    @property
    def balance(self):
        return self.__balance

    @balance.setter
    def balance(self, value):
        self.__balance = value

    def info(self):
        return f'BankAccount nr {self._nr} has a balance {BankAccount.currency} {self.__balance}'

    def deposit(self, amount):
        self.__balance += amount

    def withdraw(self, amount):
        self.__balance -= amount


# MRO - Method Resolution Order
class SavingsAccount(BankAccount, Notes):

    def __init__(self, holder, nr, interest = 0):

        BankAccount.__init__(self, holder, nr)
        Notes.__init__(self)

        # super().__init__(holder, nr)

        self._interest = interest

    # Override
    def info(self):
        return f'Savings Account (interest = {self._interest}%) nr {self._nr} has a balance {BankAccount.currency} {self.balance}'

    def interest_payout(self, period):
        self.balance += period/365 * self._interest / 100 * self.balance

    def deposit(self, amount):
        super().deposit(amount)
        self.add(f'Deposit {amount}')

    def withdraw(self, amount):
        super().withdraw(amount)
        self.add(f'Withdraw {amount}')

#=======================================================

if __name__ == '__main__':

    acc1 = SavingsAccount('Peter', 'NL65ABCD09786454788', 10)

    print(acc1.info())

    acc1.deposit(1000)
    acc1.withdraw(40)
    acc1.withdraw(65)

    print(acc1.info())

    acc1.interest_payout(30)

    print(acc1.info())
