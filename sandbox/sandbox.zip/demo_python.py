
woorden = 'de kat springt over de hond'.upper().split()

print(type(woorden))
print(woorden)

for woord in woorden:
    print(woord)
