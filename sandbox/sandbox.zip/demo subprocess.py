import subprocess

subprocess.run('calc')